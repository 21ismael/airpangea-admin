const seatLayout = 'O XXO OXO OOX OOO OXO OOX OOO OOX OXO OX';

function renderSeatMap(seatLayout) {
    const seatmapContainer = document.querySelector('.seatmap-container');

    for (let i = 0; i < seatLayout.length; i++) {
        const seat = document.createElement('div');
        seat.classList.add('seat');

        if (seatLayout[i] === 'X') {
            seat.classList.add('unavailable');
        } else if (seatLayout[i] === 'O') {
            seat.classList.add('available');
        } else {
            seat.classList.remove('seat');
            seat.classList.add('hall');
        }

        seatmapContainer.appendChild(seat);
    }
}

renderSeatMap(seatLayout);